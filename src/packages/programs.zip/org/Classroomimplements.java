//package packages.org;
//
////public  class Classroomimplements implements studentsinterface,teachersinterface{
//	
//	public void english_teacher() {
//		System.out.println("Meghna");
//		
//	}
//
//	public void science_teacher() {
//		System.out.println("Meghna");
//
//	}
//
//	public void maths_teacher() {
//		System.out.println("Meghna");
//
//	}
//
//	
//	public void studentnumber() {
//		System.out.println(8);
//
//	}
//
//	public void studentage() {
//		System.out.println(24);
//
//	}
//}
