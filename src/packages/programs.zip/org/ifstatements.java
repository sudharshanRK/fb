package packages.org;

public class ifstatements {
	public static void main(String[] args) {
		int i=1;
		if (i<5) {
			System.out.println(i);
		}
	}

}
