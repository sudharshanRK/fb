package packages.org;

public class Third_task_oopsconcept extends Second_Task_Program_Creation{

	private void Studentsdetails() {
System.out.println("Name:Ram");
	} 
	
	public static void main(String[] args) {
Third_task_oopsconcept obj = new Third_task_oopsconcept();
obj.Studentsdetails();
obj.studentclass();
	}
}
