package packages.org;

public class Second_Task_Program_Creation {
	
	private void Studentsdetails() {
System.out.println("Name:Ram");
	} 
	
	private void studentage() {
		System.out.println("age:24");
			} 
	
	public void studentclass() {
		System.out.println("class:12th");
	} 


	public static void main(String[] args) {
Second_Task_Program_Creation obj = new Second_Task_Program_Creation();
obj.Studentsdetails();
obj.studentage();
obj.studentclass();
	}

}
