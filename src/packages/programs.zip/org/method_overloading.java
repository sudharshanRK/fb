//package packages.org;
//
//public class method_overloading {
//	
////Public void calculator(){
//	System.out.println("Mobile");
//}
////Public void calculators(int a) {
//	System.out.println("calci:"+a);
//}
//
//public statis void main(string[]args) {
//	method_overloading obj = new method_overloading();
//	obj.calculator();
//	obj.calculators(7);
//}
//}
