package packages.org;

public class ifelsestatements {
public static void main(String[] args) {
	 for(int i=1; i<5; i++) {
		 if(i==4) {
			 System.out.println(true);
		 }else {
			 System.out.println(false);
		 }
			 
	 }
}
}
