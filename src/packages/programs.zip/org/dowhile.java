package packages.org;

public class dowhile {
	public static void main(String[] args) {
		int i=1;
		do {
			System.out.println(i);
			i++;	
		}while(i<5);
	}

}
