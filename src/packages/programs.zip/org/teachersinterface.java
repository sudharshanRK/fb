package packages.org;

public interface teachersinterface {
  public  void english_teacher(); 
  public  void science_teacher(); 
  public  void maths_teacher(); 

}
