package packages.org;

public interface studentsinterface {
	
	public void studentname();
	public void studentnumber();
	public void studentage();

}
